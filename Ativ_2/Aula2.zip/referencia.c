#include <stdlib.h>
#include <stdio.h>

void troca(int *a, int *b)
/*
    Troca o valor de a pelo valor de b e vice-versa.
*/
{
    int aux = *a;
    *a = *b;
    *b = aux;
}

int main ()
{
    int x=5;
    int y=2;
    
    printf("x = %d, y = %d \n",x,y);
    troca(&x,&y);
    printf("x = %d, y = %d \n",x,y);

    return 0;
}

