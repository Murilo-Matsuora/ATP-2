#include <stdlib.h>
#include <stdio.h>
#include "vetor.h"

int main()
{
    float data[8] = {4,2,5,7,9,13,68,1};
    vetor v = new_vetor(data,8);

    ordena(v,menor);
    printf("Vetor ordenado de forma crescente: ");
    imprime_vetor(v);
    printf("\n");

    ordena(v,maior);
    printf("Vetor ordenado de forma decrescente: ");
    imprime_vetor(v);

    return 0;
}