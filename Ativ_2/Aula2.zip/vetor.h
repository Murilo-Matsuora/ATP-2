
typedef struct
{
    float *data; //dados do vetor
    int n; //tamanho do vetor
} vetor;

vetor new_vetor(float *data, int n);
float soma_vetor(vetor v);
void imprime_vetor(vetor v);

int menor(float x, float y);
int maior(float x, float y);
void troca(vetor v, int i, int j);
void ordena(vetor v, int (*compara)(float,float));