#include <stdlib.h>
#include <stdio.h>

float soma(float *x, int n)
/*
    Retorna a soma dos elementos do vetor de n elementos x. Note que o vetor
    x é passado por referência.
*/
{
    //Checa se x não é NULL.
    if (x==NULL)
    {
        printf("Vetor inserido é NULL. Retornando 0.");
        return 0;
    }

    //Variável para armazenar a soma
    float sum = 0;
    
    /*Inicializa um ponteiro para iterar sobre os elementos de x. x aponta para
    seu primeiro elemento. Iteramos até que aux aponte para o endereço do úl-
    timo elemento de x.*/
    for (float *aux = x; aux <= &x[n-1]; aux++)
    {
        //Adiciona valor de aux a sum
        sum += *aux;
        //printf("%p \n",aux);
    }

    return sum;
}

int main ()
{

    float x[8] = {1,4,5.5,6,7,8.012,96,12};

    printf("%f",soma(x,8));

    return 0;
}